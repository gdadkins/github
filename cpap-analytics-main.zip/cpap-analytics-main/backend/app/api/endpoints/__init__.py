# This file makes the endpoints directory a Python package
