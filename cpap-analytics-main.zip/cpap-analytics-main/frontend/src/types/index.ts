export interface User {
  id: number;
  username: string;
  email: string;
  created_at: string;
  is_active: boolean;
}

export interface Session {
  id: number;
  user_id: number;
  date: string;
  duration_hours: number;
  ahi: number;
  mask_leak: number;
  pressure_avg: number;
  pressure_95?: number;
  quality_score: number;
  central_apneas?: number;
  obstructive_apneas?: number;
  hypopneas?: number;
  created_at: string;
}

export interface FileUpload {
  id: number;
  user_id: number;
  filename: string;
  original_filename: string;
  file_size: number;
  file_type: string;
  upload_date: string;
  processing_status: 'pending' | 'processing' | 'completed' | 'failed';
  error_message?: string;
  sessions_imported: number;
}

export interface AnalyticsSummary {
  total_sessions: number;
  avg_ahi: number;
  avg_quality: number;
  avg_duration: number;
  avg_leak: number;
}

export interface TrendData {
  date: string;
  ahi: number;
  quality_score: number;
  duration_hours: number;
}

export interface AnalyticsData {
  summary: AnalyticsSummary;
  trends: TrendData[];
  recent_sessions: Session[];
}

export interface AuthResponse {
  access_token: string;
  user: User;
}

export interface ApiError {
  error: string;
}

export interface AuthUser {
  id: number;
  username: string;
  email: string;
  full_name?: string;
  created_at: string;
  is_active: boolean;
}

export interface AuthContextType {
  user: AuthUser | null;
  loading: boolean;
  setUser: (user: AuthUser | null) => void;
}

export interface Device {
  id: number;
  manufacturer: string;
  model: string;
  serial_number: string;
  firmware_version: string;
  is_active: boolean;
  is_primary?: boolean;
}

export interface UserProfile {
  user: AuthUser;
  devices: Device[];
  statistics: {
    total_nights: number;
    average_ahi: number;
    average_duration_hours: number;
    compliance_rate_percent: number;
    date_range: {
      first_session: string;
      last_session: string;
    };
  };
}
