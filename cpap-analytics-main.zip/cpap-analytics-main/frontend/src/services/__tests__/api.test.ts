import { apiService, ApiService } from '../api';

// Mock fetch
global.fetch = jest.fn();
const mockFetch = fetch as jest.MockedFunction<typeof fetch>;

// Mock localStorage
const mockLocalStorage = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  removeItem: jest.fn(),
  clear: jest.fn(),
};
Object.defineProperty(window, 'localStorage', {
  value: mockLocalStorage
});

// Helper to create proper Response mocks
const createMockResponse = (data: unknown, options: { ok?: boolean; status?: number; statusText?: string } = {}) => ({
  ok: options.ok ?? true,
  status: options.status ?? 200,
  statusText: options.statusText ?? 'OK',
  json: async () => data,
  text: async () => JSON.stringify(data),
  headers: new Headers(),
  redirected: false,
  type: 'basic' as ResponseType,
  url: '',
  clone: jest.fn(),
  body: null,
  bodyUsed: false,
  arrayBuffer: jest.fn(),
  blob: jest.fn(),
  formData: jest.fn(),
  bytes: jest.fn(),
} as unknown as Response);

describe('API Service', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockLocalStorage.getItem.mockReturnValue(null);
  });

  describe('Authentication', () => {
    it('should login successfully', async () => {
      const mockResponse = {
        access_token: 'mock-token',
        token_type: 'bearer',
        user: {
          id: 1,
          username: 'testuser',
          email: 'test@example.com'
        }
      };

      mockFetch.mockResolvedValueOnce(createMockResponse(mockResponse));

      const result = await apiService.login('testuser', 'password123');

      expect(mockFetch).toHaveBeenCalledWith(
        'http://localhost:5000/api/auth/login',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: 'testuser', password: 'password123' })
        }
      );

      expect(result).toEqual({
        access_token: 'mock-token',
        user: mockResponse.user
      });

      expect(mockLocalStorage.setItem).toHaveBeenCalledWith('access_token', 'mock-token');
    });

    it('should handle login failure', async () => {
      mockFetch.mockResolvedValueOnce(createMockResponse(
        { detail: 'Invalid credentials' },
        { ok: false, status: 401, statusText: 'Unauthorized' }
      ));

      await expect(apiService.login('wronguser', 'wrongpass'))
        .rejects.toThrow('Authentication required');
    });

    it('should register new user', async () => {
      const mockUser = {
        id: 1,
        username: 'newuser',
        email: 'new@example.com'
      };

      mockFetch.mockResolvedValueOnce(createMockResponse(mockUser));

      const result = await apiService.register('newuser', 'new@example.com', 'password123');

      expect(mockFetch).toHaveBeenCalledWith(
        'http://localhost:5000/api/auth/register',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            username: 'newuser', 
            email: 'new@example.com', 
            password: 'password123' 
          })
        }
      );

      expect(result).toEqual(mockUser);
    });

    it('should logout successfully', async () => {
      // Create a new API service instance with the token
      const apiServiceWithToken = new ApiService();
      (apiServiceWithToken as any).token = 'mock-token';
      mockLocalStorage.getItem.mockReturnValue('mock-token');
      
      mockFetch.mockResolvedValueOnce(createMockResponse({ message: 'Successfully logged out' }));

      await apiServiceWithToken.logout();

      expect(mockFetch).toHaveBeenCalledWith(
        'http://localhost:5000/api/auth/logout',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer mock-token'
          },
          body: undefined
        }
      );

      expect(mockLocalStorage.removeItem).toHaveBeenCalledWith('access_token');
    });
  });

  describe('Profile', () => {
    it('should get user profile', async () => {
      // Create a new API service instance with the token
      const apiServiceWithToken = new ApiService();
      (apiServiceWithToken as any).token = 'mock-token';
      mockLocalStorage.getItem.mockReturnValue('mock-token');
      
      const mockProfile = {
        id: 1,
        username: 'testuser',
        email: 'test@example.com'
      };

      mockFetch.mockResolvedValueOnce(createMockResponse({ user: mockProfile }));

      const result = await apiServiceWithToken.getProfile();

      expect(mockFetch).toHaveBeenCalledWith(
        'http://localhost:5000/api/auth/profile',
        {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer mock-token'
          }
        }
      );

      expect(result).toEqual(mockProfile);
    });

    it('should handle unauthorized profile request', async () => {
      // Create a new API service instance with the token
      const apiServiceWithToken = new ApiService();
      (apiServiceWithToken as any).token = 'invalid-token';
      mockLocalStorage.getItem.mockReturnValue('invalid-token');
      
      mockFetch.mockResolvedValueOnce(createMockResponse(
        { detail: 'Invalid token' },
        { ok: false, status: 401, statusText: 'Unauthorized' }
      ));

      await expect(apiServiceWithToken.getProfile()).rejects.toThrow('Authentication required');
      expect(mockLocalStorage.removeItem).toHaveBeenCalledWith('access_token');
    });
  });

  describe('Analytics', () => {
    it('should get analytics data', async () => {
      // Create a new API service instance with the token
      const apiServiceWithToken = new ApiService();
      (apiServiceWithToken as any).token = 'mock-token';
      mockLocalStorage.getItem.mockReturnValue('mock-token');
      
      const mockAnalytics = {
        summary: {
          total_sessions: 30,
          avg_ahi: 4.2,
          avg_duration: 7.5,
          avg_quality: 95.5,
          avg_leak: 8.5
        },
        trends: [
          { date: '2025-01-01', ahi: 4.0, duration_hours: 7.5, quality_score: 85 }
        ],
        recent_sessions: [
          { 
            id: 1, 
            date: '2025-01-01', 
            duration_hours: 7.5, 
            ahi: 4.2, 
            leak_rate: 8.5, 
            compliance_hours: 7.2 
          }
        ]
      };

      mockFetch.mockResolvedValueOnce(createMockResponse(mockAnalytics));

      const result = await apiServiceWithToken.getAnalytics();

      expect(mockFetch).toHaveBeenCalledWith(
        'http://localhost:5000/api/sessions/analytics',
        {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer mock-token'
          }
        }
      );

      expect(result).toEqual(mockAnalytics);
    });

    it('should handle analytics request without token', async () => {
      mockLocalStorage.getItem.mockReturnValue(null);

      await expect(apiService.getAnalytics()).rejects.toThrow('No authentication token found');
    });
  });

  describe('Error Handling', () => {
    it('should handle network errors', async () => {
      mockFetch.mockRejectedValueOnce(new Error('Network error'));

      await expect(apiService.login('test', 'test')).rejects.toThrow('Network error');
    });

    it('should handle non-JSON responses', async () => {
      const mockResponse = createMockResponse(
        'Internal Server Error',
        { ok: false, status: 500, statusText: 'Internal Server Error' }
      );
      mockResponse.json = async () => { throw new Error('Invalid JSON'); };
      mockFetch.mockResolvedValueOnce(mockResponse);

      await expect(apiService.login('test', 'test')).rejects.toThrow('HTTP error! status: 500');
    });

    it('should handle missing error details', async () => {
      mockFetch.mockResolvedValueOnce(createMockResponse(
        {},
        { ok: false, status: 400, statusText: 'Bad Request' }
      ));

      await expect(apiService.login('test', 'test')).rejects.toThrow('HTTP error! status: 400');
    });
  });

  describe('Token Management', () => {
    it('should use stored token for authenticated requests', async () => {
      // Create a new API service instance with the token
      const apiServiceWithToken = new ApiService();
      (apiServiceWithToken as any).token = 'stored-token';
      mockLocalStorage.getItem.mockReturnValue('stored-token');
      
      mockFetch.mockResolvedValueOnce(createMockResponse({ user: { id: 1, username: 'test' } }));

      await apiServiceWithToken.getProfile();

      expect(mockFetch).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          headers: expect.objectContaining({
            'Authorization': 'Bearer stored-token'
          })
        })
      );
    });

    it('should clear token on 401 responses', async () => {
      // Create a new API service instance with the token
      const apiServiceWithToken = new ApiService();
      (apiServiceWithToken as any).token = 'invalid-token';
      mockLocalStorage.getItem.mockReturnValue('invalid-token');
      
      mockFetch.mockResolvedValueOnce(createMockResponse(
        { detail: 'Token expired' },
        { ok: false, status: 401, statusText: 'Unauthorized' }
      ));

      await expect(apiServiceWithToken.getProfile()).rejects.toThrow();
      expect(mockLocalStorage.removeItem).toHaveBeenCalledWith('access_token');
    });
  });
});