// React import not needed with new JSX transform
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Dashboard from '../Dashboard';
import { apiService } from '../../services/api';
import { AnalyticsData, UserProfile } from '../../types';

// Mock the API service
jest.mock('../../services/api');
const mockApiService = apiService as jest.Mocked<typeof apiService>;

// Mock chart components
jest.mock('../charts', () => ({
  AHITrendChart: ({ data }: { data: unknown[] }) => <div data-testid="ahi-trend-chart">AHI Chart: {data.length} points</div>,
  SleepQualityChart: ({ data }: { data: unknown[] }) => <div data-testid="sleep-quality-chart">Sleep Quality Chart: {data.length} points</div>,
  TherapyInsights: ({ data, recentSessions }: { data: unknown[]; recentSessions: unknown[] }) => <div data-testid="therapy-insights">Insights: {data.length} trends, {recentSessions.length} sessions</div>,
  EventBreakdownChart: ({ data }: { data: unknown[] }) => <div data-testid="event-breakdown-chart">Events Chart: {data.length} points</div>
}));

jest.mock('../DateRangeSelector', () => {
  return function DateRangeSelector({ value, onChange }: { value: string; onChange: (value: string) => void }) {
    return (
      <select data-testid="date-range-selector" value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="7d">7 days</option>
        <option value="30d">30 days</option>
        <option value="90d">90 days</option>
      </select>
    );
  };
});

jest.mock('../charts/ComplianceHeatmap', () => {
  return function ComplianceHeatmap({ data }: { data: unknown[] }) {
    return <div data-testid="compliance-heatmap">Heatmap: {data.length} sessions</div>;
  };
});

jest.mock('../SmartInsights', () => {
  return function SmartInsights() {
    return <div data-testid="smart-insights">Smart Insights Component</div>;
  };
});

const mockProfile: UserProfile = {
  user: {
    id: 1,
    username: 'testuser',
    email: 'test@example.com',
    created_at: '2024-01-01T00:00:00Z',
    is_active: true
  },
  devices: [],
  statistics: {
    total_nights: 30,
    average_ahi: 4.2,
    average_duration_hours: 7.5,
    compliance_rate_percent: 95.5,
    date_range: {
      first_session: '2024-01-01',
      last_session: '2024-01-30'
    }
  }
};

const mockAnalytics: AnalyticsData = {
  summary: {
    total_sessions: 30,
    avg_ahi: 4.2,
    avg_duration: 7.5,
    avg_quality: 95.5,
    avg_leak: 8.5
  },
  trends: Array.from({ length: 30 }, (_, i) => ({
    date: new Date(Date.now() - i * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    ahi: 4.0 + Math.random() * 2,
    duration_hours: 7.0 + Math.random() * 2,
    quality_score: 80 + Math.random() * 20
  })),
  recent_sessions: Array.from({ length: 10 }, (_, i) => ({
    id: i + 1,
    user_id: 1,
    date: new Date(Date.now() - i * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    duration_hours: 7.5,
    ahi: 4.2,
    mask_leak: 8.5,
    pressure_avg: 10.0,
    pressure_95: 12.0,
    quality_score: 85,
    created_at: new Date(Date.now() - i * 24 * 60 * 60 * 1000).toISOString()
  }))
};

const mockOnLogout = jest.fn();

describe('Dashboard Component', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockApiService.getUserProfile.mockResolvedValue(mockProfile);
    mockApiService.getAnalytics.mockResolvedValue(mockAnalytics);
  });

  it('renders loading state initially', () => {
    render(<Dashboard onLogout={mockOnLogout} />);
    expect(screen.getByText(/loading/i)).toBeInTheDocument();
  });

  it('loads and displays user profile and analytics data', async () => {
    render(<Dashboard onLogout={mockOnLogout} />);

    await waitFor(() => {
      expect(screen.getByText('Welcome back, test@example.com')).toBeInTheDocument();
    });

    expect(mockApiService.getUserProfile).toHaveBeenCalled();
    expect(mockApiService.getAnalytics).toHaveBeenCalled();
  });

  it('displays analytics summary correctly', async () => {
    render(<Dashboard onLogout={mockOnLogout} />);

    await waitFor(() => {
      expect(screen.getByText('30')).toBeInTheDocument(); // total sessions
      expect(screen.getByText('4.2')).toBeInTheDocument(); // avg AHI
      expect(screen.getByText('7.5h')).toBeInTheDocument(); // avg duration
      expect(screen.getByText('95.5%')).toBeInTheDocument(); // compliance rate
    });
  });

  it('renders all chart components', async () => {
    render(<Dashboard onLogout={mockOnLogout} />);

    await waitFor(() => {
      expect(screen.getByTestId('ahi-trend-chart')).toBeInTheDocument();
      expect(screen.getByTestId('sleep-quality-chart')).toBeInTheDocument();
      expect(screen.getByTestId('therapy-insights')).toBeInTheDocument();
      expect(screen.getByTestId('event-breakdown-chart')).toBeInTheDocument();
    });
  });

  it('handles date range selection', async () => {
    const user = userEvent.setup();
    render(<Dashboard onLogout={mockOnLogout} />);

    await waitFor(() => {
      expect(screen.getByTestId('date-range-selector')).toBeInTheDocument();
    });

    const selector = screen.getByTestId('date-range-selector');
    await user.selectOptions(selector, '7d');

    expect(selector).toHaveValue('7d');
    // Charts should update with filtered data
    await waitFor(() => {
      expect(screen.getByText(/AHI Chart: 7 points/)).toBeInTheDocument();
    });
  });

  it('handles API errors gracefully', async () => {
    mockApiService.getUserProfile.mockRejectedValue(new Error('API Error'));
    mockApiService.getAnalytics.mockRejectedValue(new Error('API Error'));

    render(<Dashboard onLogout={mockOnLogout} />);

    await waitFor(() => {
      expect(screen.getByText(/failed to load profile/i)).toBeInTheDocument();
    });
  });

  it('calls logout function when logout button is clicked', async () => {
    const user = userEvent.setup();
    render(<Dashboard onLogout={mockOnLogout} />);

    await waitFor(() => {
      expect(screen.getByText('Welcome back, test@example.com')).toBeInTheDocument();
    });

    const logoutButton = screen.getByRole('button', { name: /logout/i });
    await user.click(logoutButton);

    expect(mockOnLogout).toHaveBeenCalled();
  });

  it('shows compliance heatmap for 30+ day ranges', async () => {
    const user = userEvent.setup();
    render(<Dashboard onLogout={mockOnLogout} />);

    await waitFor(() => {
      expect(screen.getByTestId('compliance-heatmap')).toBeInTheDocument();
    });

    // Switch to 7-day range (should hide heatmap)
    const selector = screen.getByTestId('date-range-selector');
    await user.selectOptions(selector, '7d');

    // Heatmap should still be visible as component shows/hides based on date range
    expect(screen.getByTestId('compliance-heatmap')).toBeInTheDocument();
  });

  it('displays premium upgrade prompts for non-premium users', async () => {
    render(<Dashboard onLogout={mockOnLogout} />);

    await waitFor(() => {
      expect(screen.getByText('Welcome back, test@example.com')).toBeInTheDocument();
    });

    // Should show premium features in charts
    expect(screen.getByTestId('therapy-insights')).toBeInTheDocument();
  });

  it('filters analytics data correctly based on date range', async () => {
    const user = userEvent.setup();
    render(<Dashboard onLogout={mockOnLogout} />);

    await waitFor(() => {
      expect(screen.getByTestId('ahi-trend-chart')).toBeInTheDocument();
    });

    // Initially should show 30 days of data
    expect(screen.getByText(/AHI Chart: 30 points/)).toBeInTheDocument();

    // Switch to 7-day range
    const selector = screen.getByTestId('date-range-selector');
    await user.selectOptions(selector, '7d');

    // Should now show 7 days of data
    await waitFor(() => {
      expect(screen.getByText(/AHI Chart: 7 points/)).toBeInTheDocument();
    });
  });

  it('handles empty analytics data', async () => {
    mockApiService.getAnalytics.mockResolvedValue({
      summary: {
        total_sessions: 0,
        avg_ahi: 0,
        avg_duration: 0,
        avg_quality: 0,
        avg_leak: 0
      },
      trends: [],
      recent_sessions: []
    });

    render(<Dashboard onLogout={mockOnLogout} />);

    await waitFor(() => {
      expect(screen.getByText('0')).toBeInTheDocument(); // total sessions
    });

    expect(screen.getByText(/AHI Chart: 0 points/)).toBeInTheDocument();
    expect(screen.getByText(/Sleep Quality Chart: 0 points/)).toBeInTheDocument();
  });
});