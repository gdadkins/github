import React from 'react';
import { AuthContextType } from '../types';
import { DEFAULT_AUTH_CONTEXT } from '../constants/auth';

// Auth context
export const AuthContext = React.createContext<AuthContextType>(DEFAULT_AUTH_CONTEXT);

// Hook to use auth context
export const useAuth = () => React.useContext(AuthContext);